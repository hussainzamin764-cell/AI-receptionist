/* Hometown Wellness AI receptionist: front end. Sections: scripted demo, schedule, call log, live agent (talks to /api/chat), microphone. */
var CLINIC="Hometown Wellness";
var SLOTS=["09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30"];
var BASE_TAKEN={"09:00":"Booked","09:30":"Booked","10:00":"Booked","11:00":"Booked","12:30":"Booked","13:00":"Booked","13:30":"Booked"};
var BASE_LOG=[
 {t:"Sun 17:42",who:"0321 5550148",intent:"Clinic hours",out:"Answered",len:"0:41",tx:"Caller asked about Sunday opening hours.\nAI: The clinic opens Monday to Saturday, 9 am to 2 pm."},
 {t:"Sun 19:05",who:"0333 5550192",intent:"Book appointment",out:"Booked",len:"2:48",tx:"Caller booked Dr. Rana for Monday 10:00 under the name S. Iqbal."},
 {t:"Sun 21:30",who:"0300 5550177",intent:"Book appointment",out:"Booked",len:"3:02",tx:"Caller booked Dr. Rana for Monday 11:00 under the name F. Anwar."},
 {t:"Sun 22:10",who:"0345 5550163",intent:"Unclear request",out:"Message taken",len:"1:15",tx:"AI could not match the request to a service and took a message for staff to return the call."}
];
var taken,log,sel=-1,run=0,scen="book";
function $(id){return document.getElementById(id)}
function reset(){newNames={};taken=JSON.parse(JSON.stringify(BASE_TAKEN));log=BASE_LOG.slice();sel=-1;renderAll()}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}

/* tabs */
var curTab="call";
function showTab(n){curTab=n;document.querySelectorAll("nav button").forEach(function(x){x.setAttribute("aria-selected",x.dataset.tab===n)});["call","live","sched","log"].forEach(function(id){$(id).hidden=id!==n});if(n==="live")liveOpen()}
function askLeave(cb){var d=$("ldlg");d.returnValue="";d.onclose=function(){if(d.returnValue==="end")cb()};d.showModal()}
document.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){
 var n=b.dataset.tab;
 if(curTab==="live"&&n!=="live"){if(live.on){askLeave(function(){liveEnd();showTab(n)});return}liveEnd()}
 showTab(n)}});
document.querySelectorAll(".seg button").forEach(function(b){b.onclick=function(){
 if(run)return;scen=b.dataset.sc;
 document.querySelectorAll(".seg button").forEach(function(x){x.setAttribute("aria-pressed",x===b)});}});

/* wave */
var wave=$("wave");for(var i=0;i<60;i++){var e=document.createElement("b");e.style.animationDelay=(-Math.random()*0.7)+"s";e.style.animationDuration=(0.35+Math.random()*0.5)+"s";wave.appendChild(e)}
function speak(w){wave.className="wave"+(w?" "+w:"")}
function stage(s){document.querySelectorAll("#stages div").forEach(function(d){d.classList.toggle("on",d.dataset.s===s)})}

/* script */
function script(){
 var D=demo();if(scen==="urgent")return[
  {w:"bot",t:"Assalam o Alaikum, "+CLINIC+". I’m an AI receptionist. How can I help you?",lat:.7},
  {w:"user",t:"My father has chest pain and I need the doctor to tell me what medicine to give him. It’s urgent.",intent:"Urgent medical request",conf:"Low: outside booking scope"},
  {w:"bot",t:"I’m sorry, I can’t give medical advice. If this is an emergency, please call Rescue 1122 now. I’ll pass a message to the clinic staff right away. Can I have your name and number?",lat:1.1},
  {w:"user",t:D.name+", "+D.phone+".",intent:"Giving contact details",conf:"High"},
  {fn:"take_message",args:'{ "name": "'+D.name+'", "phone": "'+D.phone+'",\n  "note": "Father with chest pain, urgent callback", "priority": "urgent" }',res:'{ "status": "saved", "notified": "front desk" }'},
  {w:"bot",t:"Thank you. Staff have been notified and will call you back as soon as possible. Please call 1122 if his condition gets worse.",lat:.9}
 ];
 return[
  {w:"bot",t:"Assalam o Alaikum, "+CLINIC+". I’m an AI receptionist. How can I help you?",lat:.7},
  {w:"user",t:"Hi, I’d like to book an appointment with Dr. Rana for tomorrow. It’s for "+D.reason+".",intent:"Book appointment",conf:"High (0.96)"},
  {fn:"check_availability",args:'{ "doctor": "Dr. Rana", "date": "2026-10-19" }',res:function(){return JSON.stringify({free:free()})}},
  {w:"bot",t:function(){var f=free();return "Tomorrow, Monday, Dr. Rana has "+f.slice(0,-1).join(", ")+" and "+f[f.length-1]+" available. Which time suits you?"},lat:1.0},
  {w:"user",t:D.slot+" please.",intent:"Choosing slot "+D.slot,conf:"High"},
  {w:"bot",t:"Great. Can I have your name and phone number?",lat:.6},
  {w:"user",t:D.name+", "+D.phone+".",intent:"Giving contact details",conf:"High"},
  {w:"bot",t:"To confirm: "+D.name+", Dr. Rana, Monday 19 October at "+D.slot+". Shall I book it?",lat:.8},
  {w:"user",t:"Yes, please.",intent:"Confirming booking",conf:"High"},
  {fn:"book_appointment",args:'{ "doctor": "Dr. Rana", "slot": "2026-10-19T'+D.slot+'",\n  "name": "'+D.name+'", "phone": "'+D.phone+'" }',res:'{ "status": "confirmed", "id": "A-1042" }',book:D.slot},
  {w:"bot",t:"Your appointment is booked. You’ll get an SMS confirmation shortly. Is there anything else?",lat:.9},
  {w:"user",t:"No, thank you.",intent:"End call",conf:"High"},
  {w:"bot",t:"Thank you for calling "+CLINIC+". Goodbye!",lat:.5}
 ];
}
function free(){return SLOTS.filter(function(s){return !taken[s]})}
var newName="";
function demo(){var n=$("dn").value.trim()||"Ayesha Khan",p=$("dp").value.trim()||"0300 5550142",r=$("dr").value.trim()||"a general check-up",s=$("ds").value||free()[0]||"11:30";return{name:n,phone:p,slot:s,reason:r}}

function addMsg(cls,who,txt){
 var d=document.createElement("div");d.className="msg "+cls;
 var s=document.createElement("small");s.textContent=who;var p=document.createElement("span");
 d.appendChild(s);d.appendChild(p);$("tx").appendChild(d);scroll();return p}
function scroll(){var t=$("tx");t.scrollTop=t.scrollHeight}
async function type(el,txt,tok,per){var w=txt.split(" ");for(var i=0;i<w.length;i++){if(tok!==run)return false;el.textContent+=(i?" ":"")+w[i];scroll();await sleep(per)}return true}

async function start(){
 if(run)return;
 if(scen==="book"&&!free().length)reset();
 var tok=++run,D0=demo(),steps=script(),transcript=[],booked=null,t0=Date.now();
 $("go").disabled=true;$("stop").disabled=false;userStop=false;$("tx").innerHTML="";$("line").classList.add("live");$("lineTxt").textContent="On a call";
 var tm=setInterval(function(){var s=Math.floor((Date.now()-t0)/1000);$("timer").textContent=Math.floor(s/60)+":"+String(s%60).padStart(2,"0")},500);
 $("intent").textContent="Listening";
 for(var i=0;i<steps.length;i++){
  if(tok!==run)break;var st=steps[i];
  if(st.fn){
   stage("act");speak("");
   var res=typeof st.res==="function"?st.res():st.res;
   var f=document.createElement("div");f.className="fn";f.textContent="Calling "+st.fn+"…";$("tx").appendChild(f);scroll();
   $("fnv").textContent=st.fn+"(\n"+st.args+"\n)";await sleep(1100);
   f.textContent=st.fn+"\n→ "+res;$("fnv").textContent+="\n→ "+res;
   if(st.book){taken[st.book]="New";newName=D0.name;booked=st.book;renderSlots()}
   transcript.push("[system] "+st.fn+" → "+res);await sleep(500);continue}
  var txt=typeof st.t==="function"?st.t():st.t;
  if(st.w==="user"){
   stage("hear");speak("user");var p=addMsg("user","Caller","");
   if(!await type(p,txt,tok,170))break;
   stage("think");speak("");$("intent").textContent=st.intent;$("conf").textContent=st.conf;await sleep(650);
  }else{
   stage("think");await sleep(450);stage("speak");speak("bot");var q=addMsg("bot","AI receptionist","");
   $("lat").textContent=st.lat.toFixed(1)+" s";
   if($("dv").checked&&window.speechSynthesis){speechSynthesis.cancel();var u=new SpeechSynthesisUtterance(txt);speechSynthesis.speak(u)}
   if(!await type(q,txt,tok,$("dv").checked?380:150))break;
  }
  transcript.push((st.w==="bot"?"AI: ":"Caller: ")+txt);await sleep(350);
 }
 clearInterval(tm);
 if(tok===run){
  var urgent=scen==="urgent",secs=Math.floor((Date.now()-t0)/1000);
  log=[{t:"Sun "+new Date().toTimeString().slice(0,5),who:D0.phone,intent:urgent?"Urgent medical request":"Book appointment",out:urgent?"Message taken":"Booked",len:Math.floor(secs/60)+":"+String(secs%60).padStart(2,"0"),tx:transcript.join("\n")}].concat(log);
  $("fnv").textContent+="\n\nCall saved to log.";
 }
 if(tok!==run&&userStop&&transcript.length>1){var s2=Math.floor((Date.now()-t0)/1000);log=[{t:"Sun "+new Date().toTimeString().slice(0,5),who:D0.phone,intent:scen==="urgent"?"Urgent medical request":"Book appointment",out:"Stopped early",len:Math.floor(s2/60)+":"+String(s2%60).padStart(2,"0"),tx:transcript.join("\n")+"\n[call stopped by the user]"}].concat(log);$("fnv").textContent+="\n\nCall stopped and saved to log."}
 stage("");speak("");run=0;$("go").disabled=false;$("stop").disabled=true;userStop=false;$("line").classList.remove("live");$("lineTxt").textContent="Line open: AI answering";
 renderAll();
}
$("go").onclick=start;var userStop=false;$("stop").onclick=function(){if(!run)return;userStop=true;run++;if(window.speechSynthesis)speechSynthesis.cancel();$("stop").disabled=true;$("fnv").textContent+="\n\nStopping the call…"};
$("reset").onclick=function(){run++;if(window.speechSynthesis)speechSynthesis.cancel();setTimeout(function(){run=0;$("go").disabled=false;$("tx").innerHTML='<p class="empty">Pick a scenario and start the demo call to watch the agent answer, check the calendar, and book.</p>';$("timer").textContent="0:00";["intent","lat","conf"].forEach(function(i){$(i).textContent="None yet"});$("fnv").textContent="Backend calls appear here.";reset();fetch("/api/calendar/reset",{method:"POST"}).catch(function(){})},50)};

/* renders */
function renderSlots(){
 var ds=$("ds"),cur=ds.value;ds.innerHTML="";free().forEach(function(s){var o=document.createElement("option");o.textContent=s;ds.appendChild(o)});ds.value=free().indexOf(cur)>=0?cur:(free().indexOf("11:30")>=0?"11:30":free()[0]||"");
 $("slots").innerHTML="";
 SLOTS.forEach(function(s){var d=document.createElement("div"),k=taken[s];
  d.className="slot "+(k==="New"?"new":k?"taken":"free");
  var b=document.createElement("b");b.textContent=s;d.appendChild(b);d.appendChild(document.createTextNode(k==="New"?(newNames[s]||newName)+" (new)":k?"Booked":"Free"));$("slots").appendChild(d)})}
function renderLog(){
 var q=$("q").value.toLowerCase(),tb=$("rows");tb.innerHTML="";
 log.forEach(function(r,i){
  if(q&&(r.who+r.intent+r.out+r.tx).toLowerCase().indexOf(q)<0)return;
  var tr=document.createElement("tr");tr.tabIndex=0;tr.setAttribute("aria-selected",i===sel);
  [r.t,r.who,r.intent].forEach(function(v){var td=document.createElement("td");td.textContent=v;tr.appendChild(td)});
  var o=document.createElement("td"),g=document.createElement("span");g.className="tag"+(r.out==="Message taken"?" m":"");g.textContent=r.out;o.appendChild(g);tr.appendChild(o);
  var l=document.createElement("td");l.textContent=r.len;tr.appendChild(l);
  var pick=function(){sel=i;renderLog()};tr.onclick=pick;tr.onkeydown=function(e){if(e.key==="Enter")pick()};
  tb.appendChild(tr)});
 var d=$("detail");d.hidden=sel<0||!log[sel];if(!d.hidden)d.textContent=log[sel].tx;
 $("m1").textContent=log.length;
 $("m2").textContent=log.filter(function(r){return r.out==="Booked"}).length;
 $("m3").textContent=log.filter(function(r){return r.out==="Message taken"}).length}
$("q").oninput=renderLog;
function renderAll(){renderSlots();renderLog()}
/* live agent */
var newNames={};
var live={on:false,hist:[],busy:false,ab:null,out:{},bookings:[],msgs:[],cur:null,tm:null,sample:null};
var CHIPS=["What are your opening hours?","How much is a consultation?","I’d like to book Dr. Rana tomorrow at 11:30","I need to cancel my appointment","Can I speak to Dr. Rana?","My father has chest pain","Do you treat dogs?"];
CHIPS.forEach(function(c){var b=document.createElement("button");b.textContent=c;b.onclick=function(){if(live.on&&!live.busy){$("li").value=c;lsend()}};$("chips").appendChild(b)});
function lscroll(){var t=$("ltx");t.scrollTop=t.scrollHeight}
function lmsg(cls,who){var d=document.createElement("div");d.className="msg "+cls;var s=document.createElement("small");s.textContent=who;var p=document.createElement("span");d.appendChild(s);d.appendChild(p);$("ltx").appendChild(d);live.cur=cls==="bot"?d:live.cur;lscroll();return p}
function ltool(name,args,res){
 var f=document.createElement("div");f.className="fn";f.textContent=name+" "+JSON.stringify(args)+"\n→ "+JSON.stringify(res);
 if(live.cur&&live.cur.parentNode===$("ltx"))$("ltx").insertBefore(f,live.cur);else $("ltx").appendChild(f);
 $("lfn").textContent=name+"("+JSON.stringify(args)+")\n→ "+JSON.stringify(res);lscroll()}
function lspeak(t,cb){if($("lv").checked&&window.speechSynthesis){speechSynthesis.cancel();var u=new SpeechSynthesisUtterance(t),d=false;function f(){if(d)return;d=true;if(cb)cb()}u.onend=f;u.onerror=f;speechSynthesis.speak(u)}else if(cb)cb()}
function digits(x){return String(x||"").replace(/\D/g,"")}
async function lagent(){
 lvStop(true);live.busy=true;$("ls").disabled=true;$("lretry").hidden=true;lstate("thinking");
 var p=lmsg("bot","AI receptionist"),t1=Date.now();p.textContent="…";
 try{
  live.ab=new AbortController();
  var res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},signal:live.ab.signal,
   body:JSON.stringify({messages:live.chat,settings:{clinicOpen:$("lo").value==="open",failBooking:$("lf").checked}})});
  var data=await res.json().catch(function(){return {}});
  if(!res.ok)throw {code:data.error||("http_"+res.status),message:data.message};
  (data.events||[]).forEach(function(e){ltool(e.name,e.args,e.result)});
  if(data.calendar){taken=data.calendar.taken;newNames=data.calendar.names;renderSlots()}
  var o=data.outcome||{};if(o.booked)live.out.booked=1;if(o.cancelled)live.out.cancelled=1;if(o.message)live.out.msg=1;
  var out=(data.text||"").trim()||"Sorry, could you repeat that?";p.textContent=out;live.hist.push("Receptionist: "+out);live.chat.push({role:"assistant",content:out});
  $("llat").textContent=((Date.now()-t1)/1000).toFixed(1)+" s";
  live.busy=false;$("ls").disabled=false;
  lstate(live.muted?"muted":(live.voice?"speaking":"typing"));
  lspeak(out,function(){if(live.on&&live.voice&&!live.muted)lvResume()});
 }catch(e){
  live.busy=false;if(!live.on)return;if(e&&e.name==="AbortError")return;
  $("ls").disabled=false;live.failed=live.cur;live.retryMode="turn";
  var why=e&&e.code==="ai_not_configured"?"The server has no API key. Add ANTHROPIC_API_KEY to .env and restart the server.":e&&e.code==="rate_limited"?"Too many messages. Wait a moment, then tap Retry.":"I couldn’t get a reply.";
  p.textContent=why;
  lstate("error","The agent didn’t respond. Tap Retry to send your last message again, or type a new one.");$("lretry").hidden=false;
 }
}
async function lsend(){
 var el=$("li"),txt=el.value.trim();if(!txt||!live.on||live.busy)return;
 lvStop(true);el.value="";lvClear();if(window.speechSynthesis)speechSynthesis.cancel();
 lmsg("user","Caller").textContent=txt;live.hist.push("Caller: "+txt);live.chat.push({role:"user",content:txt});
 lagent();
}
$("ls").onclick=lsend;$("li").onkeydown=function(e){if(e.key==="Enter")lsend()};

/* conversation lifecycle */
live.gen=0;live.voice=false;live.muted=false;live.opening=false;live.retryMode="open";
var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
var lv={on:false};
var NOSR="Voice input isn’t available in this browser because it has no built-in speech-to-text. Try Chrome, Edge or Safari, or continue by typing. For the production app, a speech-to-text service (for example Deepgram or Azure Speech) must be configured.";
var DENIED="Microphone access is blocked. To enable it, click the lock icon next to the page address, set Microphone to Allow, then tap Retry. On a phone, allow Microphone for your browser in system settings. If this page is embedded, open it in its own tab. You can also continue by typing.";
var VERR={"not-allowed":DENIED,"service-not-allowed":DENIED,"audio-capture":"No microphone was found. Plug one in or check your device settings, then tap Retry.","network":"The speech service couldn’t be reached. Check your connection and tap Retry, or type your message."};
var LS={connecting:"Connecting",needmic:"Microphone access needed",novoice:"Voice not available",listening:"Listening",thinking:"Agent is replying",speaking:"Agent is speaking",muted:"Microphone muted",review:"Review your message",error:"Connection problem",ended:"Conversation ended",typing:"Typing only"};
var DEF={connecting:"Setting up the microphone and the agent.",listening:"Speak any time and pause when you’re done. You can also type.",speaking:"Listening resumes when the agent finishes.",muted:"Tap the microphone to talk again, or type.",review:"Edit the text if needed, then press Send, or tap Discard.",typing:"Voice is off. Type your message, or tap the microphone to turn voice on.",ended:"Open this tab again to start a new conversation."};
function lsay(m){$("lstat").textContent=m}
function lstate(s,m){$("lbadge").dataset.s=s;$("lbt").textContent=LS[s];lsay(LS[s]+". "+(m||DEF[s]||""))}
function lvUI(rec){$("lm").classList.toggle("on",rec);$("lrec").hidden=!rec;if(rec)$("lrt").textContent="Listening…"}
function lmUI(){$("lm").setAttribute("aria-pressed",live.voice&&!live.muted?"true":"false")}
function lvClear(){$("lrev").hidden=true;live.reviewing=false}
function lvStop(discard){if(!lv.on)return;lv.discard=!!discard;clearTimeout(lv.t);try{discard?lv.rc.abort():lv.rc.stop()}catch(e){lvEnded()}}

async function lmicAccess(){
 if(!SR)return {s:"novoice",m:NOSR};
 var fp=document.permissionsPolicy||document.featurePolicy;if(fp&&fp.allowsFeature&&!fp.allowsFeature("microphone"))return {s:"needmic",m:"Your browser can’t show a microphone prompt here because the frame hosting this page doesn’t allow microphone access. This is a limit of the viewer, not your browser settings, so Retry won’t change it. Tap Continue by typing, and the agent still answers aloud."};
 try{var ps=await navigator.permissions.query({name:"microphone"});if(ps.state==="denied")return {s:"needmic",m:DENIED}}catch(e){}
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return "ok";
 try{var st=await navigator.mediaDevices.getUserMedia({audio:true});st.getTracks().forEach(function(t){t.stop()});return "ok"}
 catch(e){var n=e&&e.name;
  if(n==="NotAllowedError"||n==="SecurityError")return {s:"needmic",m:DENIED};
  if(n==="NotFoundError"||n==="OverconstrainedError")return {s:"needmic",m:VERR["audio-capture"]};
  return {s:"needmic",m:"The microphone couldn’t be opened ("+(n||"unknown error")+"). Close other apps that use it, then tap Retry."}}
}
function lblocked(m,mode){live.retryMode=mode;$("lretry").hidden=false;$("ltype").hidden=!!live.on;lstate(m.s,m.m)}

async function liveOpen(){
 if(live.on||live.opening)return;
 live.opening=true;var g=++live.gen;
 $("lretry").hidden=true;$("ltype").hidden=true;$("ltx").innerHTML="";lstate("connecting");
 var m=await lmicAccess();
 if(g!==live.gen)return;
 if(m!=="ok"){live.opening=false;lblocked(m,"open");return}
 var h=null;try{h=await (await fetch("/api/health")).json()}catch(e){}
 if(g!==live.gen)return;
 if(!h||!h.ok){live.opening=false;live.retryMode="open";$("lretry").hidden=false;lstate("error","I can’t reach the server. Make sure it is running (npm start), then tap Retry.");return}
 if(!h.aiConfigured){live.opening=false;live.retryMode="open";$("lretry").hidden=false;lstate("error","The server has no ANTHROPIC_API_KEY. Add it to .env, restart the server, then tap Retry.");return}
 try{var c=await (await fetch("/api/calendar")).json();taken=c.taken;newNames=c.names;renderSlots()}catch(e){}
 lbegin(true);
}
function lbegin(voice){
 live.opening=false;live.on=true;live.voice=voice;live.muted=false;live.busy=false;live.hist=[];live.chat=[];live.out={};live.msgs=[];live.failed=null;
 $("ltx").innerHTML="";$("lretry").hidden=true;$("ltype").hidden=true;
 ["li","ls","lm"].forEach(function(i){$(i).disabled=false});lmUI();
 var open=$("lo").value==="open";
 var g="Assalam o Alaikum, "+CLINIC+". I’m an AI receptionist."+(open?"":" The clinic is closed right now, but I can help with bookings and messages.")+" How can I help you?";
 lmsg("bot","AI receptionist").textContent=g;live.hist.push("Receptionist: "+g);
 var t0=Date.now();live.t0=t0;clearInterval(live.tm);live.tm=setInterval(function(){var x=Math.floor((Date.now()-t0)/1000);$("ltimer").textContent=Math.floor(x/60)+":"+String(x%60).padStart(2,"0")},500);
 $("line").classList.add("live");$("lineTxt").textContent="On a call";
 lstate(voice?"speaking":"typing");
 lspeak(g,function(){if(live.on&&live.voice&&!live.muted)lvResume()});
}
function liveEnd(){
 live.gen++;var was=live.on;
 if(!was&&!live.opening)return;
 live.on=false;live.opening=false;clearInterval(live.tm);lvStop(true);lvClear();if(live.ab)live.ab.abort();if(window.speechSynthesis)speechSynthesis.cancel();live.busy=false;
 var callerTurns=live.hist.filter(function(h){return h.indexOf("Caller:")===0});
 if(was&&callerTurns.length){var o=live.out,secs=Math.floor((Date.now()-live.t0)/1000);
  log=[{t:"Sun "+new Date().toTimeString().slice(0,5),who:"Live demo caller",intent:callerTurns[0].slice(8,48),out:o.booked?"Booked":o.cancelled?"Cancelled":o.msg?"Message taken":"Answered",len:Math.floor(secs/60)+":"+String(secs%60).padStart(2,"0"),tx:live.hist.join("\n")}].concat(log)}
 ["li","ls","lm"].forEach(function(i){$(i).disabled=true});$("lrec").hidden=true;$("lm").classList.remove("on");$("lretry").hidden=true;$("ltype").hidden=true;
 $("line").classList.remove("live");$("lineTxt").textContent="Line open: AI answering";lstate("ended");renderAll();
}

function lvResume(){
 if(!live.on||!live.voice||live.muted||live.busy||lv.on||live.reviewing||document.hidden||!SR)return;
 if(window.speechSynthesis&&speechSynthesis.speaking)return;
 var rc=new SR();rc.lang=navigator.language||"en-US";rc.continuous=true;rc.interimResults=true;rc.maxAlternatives=1;
 lv={on:true,rc:rc,final:"",interim:"",conf:[],discard:false,err:null,silent:lv.silent||0,t:0};
 rc.onstart=function(){lvUI(true);if($("lbadge").dataset.s!=="listening")lstate("listening")};
 rc.onresult=function(e){var f="",t="";lv.conf=[];for(var i=0;i<e.results.length;i++){var r=e.results[i];if(r.isFinal){f+=r[0].transcript+" ";lv.conf.push(r[0].confidence)}else t+=r[0].transcript}
  lv.final=f;lv.interim=t;$("lrt").textContent=(f+t).trim()||"Listening…";
  clearTimeout(lv.t);if(e.results.length&&e.results[e.results.length-1].isFinal)lv.t=setTimeout(function(){lvStop(false)},1100)};
 rc.onerror=function(e){lv.err=e.error};
 rc.onend=lvEnded;
 try{rc.start()}catch(x){lv.on=false;live.voice=false;lmUI();lblocked({s:"error",m:"The microphone couldn’t start. Tap Retry, or type your message."},"mic")}
}
function lvEnded(){
 if(!lv.on)return;lv.on=false;clearTimeout(lv.t);lvUI(false);
 var err=lv.err,txt=(lv.final+" "+lv.interim).trim().replace(/\s+/g," ");
 if(lv.discard||!live.on)return;
 if(err&&VERR[err]){live.voice=false;lmUI();lblocked({s:err==="network"?"error":"needmic",m:VERR[err]},"mic");return}
 if(err&&err!=="no-speech"&&err!=="aborted"){live.voice=false;lmUI();lblocked({s:"error",m:"Something went wrong with the microphone ("+err+"). Tap Retry, or type your message."},"mic");return}
 if(txt.length<2){lv.silent=(lv.silent||0)+1;
  if(lv.silent>=3){lv.silent=0;lsay("Listening. I’m not hearing anything. Check that your microphone isn’t muted or move somewhere quieter. You can also type.")}
  setTimeout(lvResume,250);return}
 lv.silent=0;
 var el=$("li"),old=el.value.trim();el.value=(old?old+" ":"")+txt;
 if($("lrv").checked){
  var c=lv.conf.filter(function(x){return x>0}),avg=c.length?c.reduce(function(a,b){return a+b},0)/c.length:1;
  live.reviewing=true;$("lrev").hidden=false;el.focus();
  lstate("review",avg<0.6?"I wasn’t sure I heard everything correctly. Please check the words, edit them if needed, then press Send, or tap Discard.":"")}
 else lsend();
}
$("lm").onclick=function(){
 if(!live.on)return;
 if(!live.voice){lmicAccess().then(function(m){if(m==="ok"){live.voice=true;live.muted=false;$("lretry").hidden=true;lmUI();lvResume()}else lblocked(m,"mic")});return}
 if(live.muted){live.muted=false;lmUI();lvResume()}else{live.muted=true;lmUI();lvStop(true);lstate("muted")}
};
$("lstop").onclick=function(){$("lm").click()};
$("ldisc").onclick=function(){$("li").value="";lvClear();lstate(live.muted?"muted":(live.voice?"listening":"typing"),"Discarded.");lvResume();$("lm").focus()};
$("lretry").onclick=function(){
 $("lretry").hidden=true;
 if(live.retryMode==="turn"){if(live.failed&&live.failed.parentNode)live.failed.remove();live.failed=null;lagent()}
 else if(live.retryMode==="mic"){$("lm").click()}
 else liveOpen()};
$("ltype").onclick=function(){$("ltype").hidden=true;$("lretry").hidden=true;if(!live.on&&!live.opening)lbegin(false)};
document.addEventListener("visibilitychange",function(){if(document.hidden)lvStop(true);else lvResume()});
window.addEventListener("pagehide",function(){liveEnd()});
window.addEventListener("beforeunload",function(e){if(live.on){e.preventDefault();e.returnValue=""}});

reset();
fetch("/api/config").then(function(r){return r.json()}).then(function(c){if(c&&c.name){CLINIC=c.name;document.title="AI Receptionist – "+c.name;$("clinicName").textContent=c.name}}).catch(function(){});
