import { buildSystemPrompt } from "./prompt.js";
import { TOOL_DEFS, runTool } from "./tools.js";
import { snapshot } from "./calendar.js";

const MAX_STEPS = 6;
const FALLBACK = "Sorry, I’m having trouble completing that. I can take a message for the staff to call you back.";

/**
 * Runs one conversational turn: calls the model, executes any tool calls on the server,
 * and returns the receptionist's reply plus the tool events for the UI.
 */
export async function runAgent({ client, model, clinic, calendar, staffMessages, history, settings }) {
  const system = buildSystemPrompt(clinic, settings);
  const messages = history.map((m) => ({ role: m.role, content: m.content }));
  const events = [];
  const outcome = { booked: false, cancelled: false, message: false };
  const ctx = { clinic, calendar, staffMessages, settings, outcome };
  let text = "";

  for (let step = 0; step < MAX_STEPS; step++) {
    const resp = await client.messages.create({
      model,
      max_tokens: 400,
      system,
      tools: TOOL_DEFS,
      messages,
    });

    if (resp.stop_reason !== "tool_use") {
      text = resp.content.filter((b) => b.type === "text").map((b) => b.text).join(" ").trim();
      break;
    }

    messages.push({ role: "assistant", content: resp.content });
    const results = [];
    for (const block of resp.content) {
      if (block.type !== "tool_use") continue;
      const { result, isError } = runTool(block.name, block.input, ctx);
      events.push({ name: block.name, args: block.input, result });
      results.push({
        type: "tool_result",
        tool_use_id: block.id,
        content: JSON.stringify(result),
        ...(isError ? { is_error: true } : {}),
      });
    }
    messages.push({ role: "user", content: results });
  }

  return { text: text || FALLBACK, events, outcome, calendar: snapshot(calendar) };
}
