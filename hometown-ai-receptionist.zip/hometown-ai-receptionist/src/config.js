import "dotenv/config";

const int = (v, d) => {
  const n = Number.parseInt(v ?? "", 10);
  return Number.isFinite(n) && n > 0 ? n : d;
};

export const config = {
  port: int(process.env.PORT, 3000),
  apiKey: (process.env.ANTHROPIC_API_KEY || "").trim(),
  model: (process.env.ANTHROPIC_MODEL || "claude-haiku-5-5").trim(),
  rateLimitPerMin: int(process.env.RATE_LIMIT_PER_MIN, 30),
  trustProxy: process.env.TRUST_PROXY === "1",
  adminToken: (process.env.ADMIN_TOKEN || "").trim(),
  clinicConfigPath: process.env.CLINIC_CONFIG || new URL("../config/clinic.json", import.meta.url),
};

export const PLACEHOLDER_KEYS = ["", "your-anthropic-api-key-here"];
export const aiConfigured = () => !PLACEHOLDER_KEYS.includes(config.apiKey);
