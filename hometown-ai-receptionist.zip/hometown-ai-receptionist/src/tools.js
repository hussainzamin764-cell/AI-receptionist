import { bookSlot, cancelSlot, freeSlots } from "./calendar.js";

// Tool definitions in the Anthropic Messages API format.
export const TOOL_DEFS = [
  {
    name: "check_availability",
    description: "List free appointment slots for a doctor on a date. Always call this before offering times.",
    input_schema: {
      type: "object",
      properties: {
        doctor: { type: "string" },
        date: { type: "string", description: "YYYY-MM-DD" },
      },
      required: ["doctor", "date"],
    },
  },
  {
    name: "book_appointment",
    description: "Book a slot. Call only after the caller has confirmed name, phone, doctor, date and time.",
    input_schema: {
      type: "object",
      properties: {
        doctor: { type: "string" },
        slot: { type: "string", description: "HH:MM on the calendar date" },
        name: { type: "string" },
        phone: { type: "string" },
      },
      required: ["slot", "name", "phone"],
    },
  },
  {
    name: "cancel_appointment",
    description: "Cancel an appointment made by this caller, identified by the phone number used to book and the slot.",
    input_schema: {
      type: "object",
      properties: { phone: { type: "string" }, slot: { type: "string" } },
      required: ["phone", "slot"],
    },
  },
  {
    name: "take_message",
    description: "Save a message for clinic staff to return the call.",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string" },
        phone: { type: "string" },
        note: { type: "string" },
        priority: { type: "string", enum: ["normal", "urgent"] },
      },
      required: ["name", "phone", "note"],
    },
  },
  {
    name: "transfer_call",
    description: "Transfer the call to a human at the clinic. Fails when no staff are available.",
    input_schema: {
      type: "object",
      properties: { to: { type: "string" }, reason: { type: "string" } },
      required: ["to"],
    },
  },
];

const clip = (v, n) => String(v ?? "").slice(0, n);

/**
 * Runs one tool call. Returns { result, isError }.
 * ctx = { clinic, calendar, staffMessages, settings: { clinicOpen, failBooking }, outcome }
 */
export function runTool(name, input, ctx) {
  const args = input && typeof input === "object" ? input : {};
  try {
    switch (name) {
      case "check_availability": {
        const last = ctx.clinic.doctor.name.toLowerCase().replace(/^dr\.?\s*/, "").trim();
        const matches = clip(args.doctor, 80).toLowerCase().includes(last);
        if (matches && args.date === ctx.calendar.date) return { result: { free: freeSlots(ctx.calendar) } };
        return { result: { free: [], note: "No calendar data for that doctor or date" } };
      }
      case "book_appointment": {
        if (ctx.settings.failBooking) {
          // Test switch: simulates the booking service being down.
          return { result: { error: "calendar service timed out. The booking was NOT saved." }, isError: true };
        }
        const result = bookSlot(ctx.calendar, args);
        if (result.status === "confirmed") ctx.outcome.booked = true;
        return { result };
      }
      case "cancel_appointment": {
        const result = cancelSlot(ctx.calendar, args);
        if (result.status === "cancelled") ctx.outcome.cancelled = true;
        return { result };
      }
      case "take_message": {
        const entry = {
          id: `M-${ctx.staffMessages.length + 1}`,
          receivedAt: new Date().toISOString(),
          name: clip(args.name, 60),
          phone: clip(args.phone, 30),
          note: clip(args.note, 500),
          priority: args.priority === "urgent" ? "urgent" : "normal",
        };
        ctx.staffMessages.push(entry);
        if (ctx.staffMessages.length > 200) ctx.staffMessages.shift();
        ctx.outcome.message = true;
        return { result: { status: "saved", id: entry.id } };
      }
      case "transfer_call": {
        if (!ctx.settings.clinicOpen) return { result: { status: "failed", reason: "no staff available" } };
        return { result: { status: "transferred", to: clip(args.to, 60) } };
      }
      default:
        return { result: { error: `unknown tool ${clip(name, 40)}` }, isError: true };
    }
  } catch (err) {
    return { result: { error: "tool failed" }, isError: true };
  }
}
