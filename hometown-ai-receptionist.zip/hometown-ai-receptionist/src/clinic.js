import { readFileSync } from "node:fs";

export function loadClinic(path) {
  const clinic = JSON.parse(readFileSync(path, "utf8"));
  for (const key of ["name", "hours", "doctor", "calendar"]) {
    if (!clinic[key]) throw new Error(`Clinic config is missing "${key}"`);
  }
  return clinic;
}
