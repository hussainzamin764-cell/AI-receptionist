// In-memory demo calendar for one doctor on one day.
// Replace this module with a real calendar or EHR integration for production.

const digits = (x) => String(x ?? "").replace(/\D/g, "");

export function createCalendar(cfg) {
  return {
    date: cfg.date,
    dateLabel: cfg.dateLabel,
    slots: [...cfg.slots],
    taken: Object.fromEntries(cfg.initiallyTaken.map((s) => [s, "Booked"])),
    names: {},
    bookings: [],
    nextId: 1043,
  };
}

export const freeSlots = (cal) => cal.slots.filter((s) => !cal.taken[s]);

export const snapshot = (cal) => ({
  date: cal.date,
  slots: [...cal.slots],
  taken: { ...cal.taken },
  names: { ...cal.names },
});

export function bookSlot(cal, { slot, name, phone }) {
  const cleanName = String(name ?? "").trim();
  const d = digits(phone);
  if (!cal.slots.includes(slot)) return { status: "failed", reason: "unknown slot" };
  if (cal.taken[slot]) return { status: "failed", reason: "slot not available" };
  if (cleanName.length < 2 || cleanName.length > 60) return { status: "failed", reason: "invalid name" };
  if (d.length < 7 || d.length > 15) return { status: "failed", reason: "invalid phone number" };
  const id = `A-${cal.nextId++}`;
  cal.taken[slot] = "New";
  cal.names[slot] = cleanName;
  cal.bookings.push({ id, slot, name: cleanName, phone: d });
  return { status: "confirmed", id };
}

// Only bookings made through this app can be cancelled, and only by the phone number used to book.
export function cancelSlot(cal, { slot, phone }) {
  const i = cal.bookings.findIndex((b) => b.slot === slot && b.phone === digits(phone));
  if (i < 0) return { status: "not_found" };
  cal.bookings.splice(i, 1);
  delete cal.taken[slot];
  delete cal.names[slot];
  return { status: "cancelled" };
}
