import test from "node:test";
import assert from "node:assert/strict";
import { createCalendar, freeSlots, bookSlot, cancelSlot } from "../src/calendar.js";

const cfg = { date: "2026-10-19", dateLabel: "Monday", slots: ["09:00", "09:30", "10:00"], initiallyTaken: ["09:00"] };

test("free slots exclude taken ones", () => {
  assert.deepEqual(freeSlots(createCalendar(cfg)), ["09:30", "10:00"]);
});

test("booking succeeds once and a second attempt fails", () => {
  const cal = createCalendar(cfg);
  const first = bookSlot(cal, { slot: "09:30", name: "Ayesha Khan", phone: "0300 5550142" });
  assert.equal(first.status, "confirmed");
  assert.equal(bookSlot(cal, { slot: "09:30", name: "Someone Else", phone: "0300 5550143" }).status, "failed");
});

test("booking rejects bad names, phones and unknown slots", () => {
  const cal = createCalendar(cfg);
  assert.equal(bookSlot(cal, { slot: "10:00", name: "A", phone: "03005550142" }).reason, "invalid name");
  assert.equal(bookSlot(cal, { slot: "10:00", name: "Ayesha", phone: "12" }).reason, "invalid phone number");
  assert.equal(bookSlot(cal, { slot: "23:00", name: "Ayesha", phone: "03005550142" }).reason, "unknown slot");
});

test("cancel needs the same phone number and frees the slot", () => {
  const cal = createCalendar(cfg);
  bookSlot(cal, { slot: "10:00", name: "Ayesha Khan", phone: "0300 5550142" });
  assert.equal(cancelSlot(cal, { slot: "10:00", phone: "0300 0000000" }).status, "not_found");
  assert.equal(cancelSlot(cal, { slot: "10:00", phone: "03005550142" }).status, "cancelled");
  assert.ok(freeSlots(cal).includes("10:00"));
});

test("pre-existing bookings cannot be cancelled through the app", () => {
  const cal = createCalendar(cfg);
  assert.equal(cancelSlot(cal, { slot: "09:00", phone: "03005550142" }).status, "not_found");
});
