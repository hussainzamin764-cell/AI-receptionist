import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createCalendar } from "../src/calendar.js";
import { runTool } from "../src/tools.js";
import { buildSystemPrompt } from "../src/prompt.js";

const clinic = JSON.parse(readFileSync(new URL("../config/clinic.json", import.meta.url), "utf8"));
const makeCtx = (settings = {}) => ({
  clinic,
  calendar: createCalendar(clinic.calendar),
  staffMessages: [],
  settings: { clinicOpen: true, failBooking: false, ...settings },
  outcome: { booked: false, cancelled: false, message: false },
});

test("check_availability only answers for the configured doctor and date", () => {
  const ctx = makeCtx();
  assert.deepEqual(runTool("check_availability", { doctor: "Dr. Rana", date: "2026-10-19" }, ctx).result.free, ["10:30", "11:30", "12:00"]);
  assert.deepEqual(runTool("check_availability", { doctor: "Dr. Rana", date: "2026-10-20" }, ctx).result.free, []);
  assert.deepEqual(runTool("check_availability", { doctor: "Dr. Smith", date: "2026-10-19" }, ctx).result.free, []);
});

test("a simulated booking failure never saves the booking", () => {
  const ctx = makeCtx({ failBooking: true });
  const out = runTool("book_appointment", { slot: "11:30", name: "Ayesha Khan", phone: "03005550142" }, ctx);
  assert.equal(out.isError, true);
  assert.equal(ctx.calendar.taken["11:30"], undefined);
  assert.equal(ctx.outcome.booked, false);
});

test("a normal booking is saved and flagged in the outcome", () => {
  const ctx = makeCtx();
  const out = runTool("book_appointment", { slot: "11:30", name: "Ayesha Khan", phone: "03005550142" }, ctx);
  assert.equal(out.result.status, "confirmed");
  assert.equal(ctx.outcome.booked, true);
});

test("transfer fails when the clinic is closed", () => {
  assert.equal(runTool("transfer_call", { to: "front desk" }, makeCtx({ clinicOpen: false })).result.status, "failed");
  assert.equal(runTool("transfer_call", { to: "front desk" }, makeCtx()).result.status, "transferred");
});

test("take_message stores a trimmed record", () => {
  const ctx = makeCtx();
  const out = runTool("take_message", { name: "Hamza Raza", phone: "0301 5550126", note: "x".repeat(900), priority: "urgent" }, ctx);
  assert.equal(out.result.status, "saved");
  assert.equal(ctx.staffMessages[0].note.length, 500);
  assert.equal(ctx.staffMessages[0].priority, "urgent");
});

test("unknown tools are rejected", () => {
  assert.equal(runTool("delete_everything", {}, makeCtx()).isError, true);
});

test("system prompt carries the approved facts and the clinic status", () => {
  const open = buildSystemPrompt(clinic, { clinicOpen: true });
  const closed = buildSystemPrompt(clinic, { clinicOpen: false });
  assert.match(open, /Hometown Wellness/);
  assert.match(open, /Rs 1,500/);
  assert.match(open, /OPEN/);
  assert.match(closed, /CLOSED/);
});
