import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createCalendar } from "../src/calendar.js";
import { runAgent } from "../src/agent.js";

const clinic = JSON.parse(readFileSync(new URL("../config/clinic.json", import.meta.url), "utf8"));

// A fake Anthropic client: first reply asks for a tool, second reply is the spoken answer.
function fakeClient(script) {
  const calls = [];
  return {
    calls,
    messages: {
      create: async (req) => {
        calls.push(req);
        return script.shift();
      },
    },
  };
}

const base = () => ({
  model: "test-model",
  clinic,
  calendar: createCalendar(clinic.calendar),
  staffMessages: [],
  history: [{ role: "user", content: "Book me at 11:30, Ayesha Khan, 0300 5550142" }],
  settings: { clinicOpen: true, failBooking: false },
});

test("agent runs the tool the model asks for, then returns the final text", async () => {
  const client = fakeClient([
    { stop_reason: "tool_use", content: [{ type: "tool_use", id: "t1", name: "book_appointment", input: { slot: "11:30", name: "Ayesha Khan", phone: "0300 5550142" } }] },
    { stop_reason: "end_turn", content: [{ type: "text", text: "Your appointment is booked." }] },
  ]);
  const out = await runAgent({ client, ...base() });
  assert.equal(out.text, "Your appointment is booked.");
  assert.equal(out.events[0].result.status, "confirmed");
  assert.equal(out.outcome.booked, true);
  assert.equal(out.calendar.taken["11:30"], "New");
  // the tool result is sent back to the model
  const second = client.calls[1].messages.at(-1);
  assert.equal(second.content[0].type, "tool_result");
});

test("a failed tool is reported to the model as an error and nothing is saved", async () => {
  const client = fakeClient([
    { stop_reason: "tool_use", content: [{ type: "tool_use", id: "t1", name: "book_appointment", input: { slot: "11:30", name: "Ayesha Khan", phone: "0300 5550142" } }] },
    { stop_reason: "end_turn", content: [{ type: "text", text: "I couldn’t save that booking." }] },
  ]);
  const args = base();
  args.settings.failBooking = true;
  const out = await runAgent({ client, ...args });
  assert.equal(client.calls[1].messages.at(-1).content[0].is_error, true);
  assert.equal(out.outcome.booked, false);
  assert.equal(out.calendar.taken["11:30"], undefined);
});

test("a model that never stops calling tools hits the step limit and falls back safely", async () => {
  const loop = () => ({ stop_reason: "tool_use", content: [{ type: "tool_use", id: "t", name: "check_availability", input: { doctor: "Dr. Rana", date: "2026-10-19" } }] });
  const client = fakeClient(Array.from({ length: 10 }, loop));
  const out = await runAgent({ client, ...base() });
  assert.match(out.text, /take a message/);
  assert.equal(client.calls.length, 6);
});
