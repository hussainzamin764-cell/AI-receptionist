# Hometown Wellness AI Receptionist

A web-based AI receptionist for a small clinic. Callers talk or type; the agent answers from approved clinic information, books, changes and cancels appointments, takes messages, and escalates urgent or out-of-scope requests.

- **Frontend:** plain HTML, CSS and JavaScript (no build step) in `public/`.
- **Backend:** Node.js and Express in `server.js` and `src/`. The backend holds the API key, builds the agent prompt, calls the Anthropic Messages API, and runs the calendar and message tools.
- **Voice:** speech to text uses the browser's built-in speech recognition. Spoken replies use the browser's speech synthesis. There is no phone line yet (see "What is not included").

All clinic facts, fees, policies and calendar slots here are **demo data**. Replace them with approved information before any real use.

## Quick start

Requirements: Node.js 20 or newer, and an Anthropic API key.

```bash
npm install
cp .env.example .env        # on Windows: copy .env.example .env
# edit .env and set ANTHROPIC_API_KEY
npm start
```

Open http://localhost:3000. Run the tests with `npm test` (they use a fake model client and need no API key).

## Where to put secrets

| Secret | Where | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | `.env` on the server | Create it in the Anthropic Console. It is read only by the server (`src/config.js`) and never sent to the browser. |
| `ADMIN_TOKEN` (optional) | `.env` | Enables `GET /api/messages`. Leave empty to keep that endpoint off. |

`.env` is listed in `.gitignore`. Never commit it, never paste keys into `public/` files, and rotate any key that was exposed. In production, use your host's secret manager or environment variables instead of a file.

## Configuration

Environment variables (see `.env.example`):

| Variable | Default | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | none | Required for the live agent. |
| `ANTHROPIC_MODEL` | `claude-haiku-5-5` | Model used for replies. A fast model keeps responses quick. |
| `PORT` | `3000` | HTTP port. |
| `TRUST_PROXY` | `0` | Set to `1` behind a reverse proxy so rate limiting sees real client IPs. |
| `RATE_LIMIT_PER_MIN` | `30` | Chat requests per minute per IP. |
| `ADMIN_TOKEN` | empty | Protects `/api/messages`. |
| `CLINIC_CONFIG` | `config/clinic.json` | Path to a different clinic file. |

**Clinic information** lives in `config/clinic.json`: name, hours, services, fees, policies, doctor, emergency number label, and the demo calendar. The agent may only state facts from this file. The page title, header and greetings read the clinic name from the server, so renaming the clinic is a one-line change.

## How it works

```
Browser (public/)                    Server (Node + Express)                Anthropic API
 text or speech  --POST /api/chat-->  validate, rate limit
                                      build system prompt from clinic.json
                                      call model with tool definitions  -->  model
                                      run tools on the server           <--  tool_use
                                      (calendar, message, transfer)     -->  tool_result
 reply + tool events  <---------------  final text + events + calendar    <--  reply
```

Each chat request sends the conversation text only. The server runs tools itself, so the model can never change the calendar except through validated tool calls, and the UI only shows a booking as done after a tool reports `confirmed`.

```
server.js              routes, security headers, rate limit, validation
src/config.js          environment variables
src/clinic.js          loads config/clinic.json
src/prompt.js          system prompt (rules + approved facts)
src/tools.js           tool definitions and implementations
src/calendar.js        in-memory demo calendar (replace for production)
src/agent.js           model + tool loop (max 6 steps)
public/index.html      page structure: scripted demo, live agent, schedule, call log
public/css/styles.css  light theme and layout
public/js/app.js       scripted demo, live agent client, microphone handling
config/clinic.json     clinic facts and demo calendar
test/                  unit tests (node:test)
```

## API

| Method and path | Purpose |
|---|---|
| `GET /api/health` | `{ ok, aiConfigured }`. The page uses it to detect a missing key. |
| `GET /api/config` | `{ name }` clinic name. |
| `POST /api/chat` | Body: `{ messages: [{role, content}], settings: { clinicOpen, failBooking } }`. The first and last messages must be from the caller (`user`). Returns `{ text, events, outcome, calendar }`. |
| `GET /api/calendar` | Current demo calendar. |
| `POST /api/calendar/reset` | Restore the demo calendar. |
| `GET /api/messages` | Messages left for staff. Needs header `x-admin-token`. Returns 404 unless `ADMIN_TOKEN` is set and matches. |

Errors: `400` bad request, `429` rate limited, `502` AI service failed, `503` API key not configured.

## Using the app

- **Live call tab:** a scripted demo of two scenarios (booking, urgent request). It needs no API key and works offline. Fill in the demo caller form to use your own name, phone and time. **Stop call** ends it at any point.
- **Talk to the agent tab:** a live conversation with the real model. It starts when the tab opens, asks for microphone access, and listens. You can type instead. Test switches: set the clinic to **After hours**, or tick **Make booking fail**, to check fallback behavior. Leaving the tab asks for confirmation.
- **Schedule** and **Call log:** show bookings and transcripts for the session. The log is held in the browser page only.

## Microphone and HTTPS

Browsers allow microphone access only on `localhost` or over HTTPS, so deploy behind HTTPS. The server sends `Permissions-Policy: microphone=(self)`, which lets the page request the microphone. Browser speech recognition works in Chrome, Edge and Safari. In Chrome and Edge it may send audio to the browser vendor's speech service. If recognition is not available, the page says so and typing still works. It never fakes a transcript.

## Docker

```bash
docker build -t hometown-ai-receptionist .
docker run --env-file .env -p 3000:3000 hometown-ai-receptionist
```

## Production checklist

- Serve over HTTPS and set `TRUST_PROXY=1` behind a proxy.
- Replace `src/calendar.js` with your real scheduling system. The calendar and staff messages here are in memory and are lost on restart.
- Add real staff authentication before exposing messages or the calendar. `ADMIN_TOKEN` is a minimal safeguard only.
- Decide retention. The server logs only method, path, status and timing, never message content. Caller names and phone numbers are held in memory and sent to the AI provider. Confirm that this matches your privacy policy and local health-data rules, and disclose AI use and any recording to callers.
- Review the agent's rules in `src/prompt.js` with clinic staff, and test the scenarios in the checklist below before launch.
- Pin dependency versions with a lockfile (`npm install` creates `package-lock.json`; commit it) and run `npm audit`.

## Suggested test scenarios

Hours, services, fees and policies; book, change and cancel; read-back of name and phone; asking for a person or department; calling after hours; a question the agent cannot answer; corrections and interruptions; an urgent request (the agent must not give medical advice and must point to emergency help); and tool failures (use **Make booking fail** and **After hours**). For each, confirm the agent only says an action is done after the tool succeeded.

## What is not included

- **Phone calls.** There is no telephony. A real phone line needs a provider such as Twilio, a streaming speech-to-text service, and text to speech, connected to the same `/api/chat` logic. The proposal's cost estimates assume that pipeline.
- **Server-side speech recognition.** The microphone feature uses the browser's recognition only.
- **Persistent storage, user accounts, SMS confirmations, and a real calendar.**
- The project was checked with unit tests and syntax checks. The full server, the browser UI and the live model calls were not run end to end when this package was assembled, so do a manual test after setup.
