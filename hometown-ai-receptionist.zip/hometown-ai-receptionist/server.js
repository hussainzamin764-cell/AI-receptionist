import { timingSafeEqual } from "node:crypto";
import { fileURLToPath } from "node:url";
import express from "express";
import rateLimit from "express-rate-limit";
import Anthropic from "@anthropic-ai/sdk";
import { config, aiConfigured } from "./src/config.js";
import { loadClinic } from "./src/clinic.js";
import { createCalendar, snapshot } from "./src/calendar.js";
import { runAgent } from "./src/agent.js";

const clinic = loadClinic(config.clinicConfigPath);
let calendar = createCalendar(clinic.calendar);
const staffMessages = []; // in memory only: lost on restart, see README for production notes

const client = aiConfigured()
  ? new Anthropic({ apiKey: config.apiKey, timeout: 20_000, maxRetries: 1 })
  : null;

const app = express();
if (config.trustProxy) app.set("trust proxy", 1);
app.disable("x-powered-by");

// Security headers. Microphone is allowed for this origin only, which is what lets the browser show its permission prompt.
app.use((req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "microphone=(self), camera=(), geolocation=()",
    "Content-Security-Policy": [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' https://fonts.googleapis.com",
      "font-src https://fonts.gstatic.com",
      "img-src 'self' data:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'none'",
      "form-action 'self'",
    ].join("; "),
  });
  next();
});

app.use(express.json({ limit: "32kb" }));

// Request log without bodies: caller names, phone numbers and speech never reach the logs.
app.use((req, res, next) => {
  const t0 = Date.now();
  res.on("finish", () => {
    if (req.path.startsWith("/api/")) console.log(`${req.method} ${req.path} ${res.statusCode} ${Date.now() - t0}ms`);
  });
  next();
});

const chatLimiter = rateLimit({
  windowMs: 60_000,
  limit: config.rateLimitPerMin,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json({ error: "rate_limited", message: "Too many messages. Wait a moment and try again." }),
});

app.get("/api/health", (req, res) => res.json({ ok: true, aiConfigured: aiConfigured() }));
app.get("/api/config", (req, res) => res.json({ name: clinic.name }));
app.get("/api/calendar", (req, res) => res.json(snapshot(calendar)));
app.post("/api/calendar/reset", (req, res) => {
  calendar = createCalendar(clinic.calendar);
  res.json(snapshot(calendar));
});

// Messages left for staff. Disabled unless ADMIN_TOKEN is set, because it exposes caller details.
app.get("/api/messages", (req, res) => {
  const given = Buffer.from(String(req.get("x-admin-token") || ""));
  const want = Buffer.from(config.adminToken);
  const ok = want.length > 0 && given.length === want.length && timingSafeEqual(given, want);
  if (!ok) return res.status(404).json({ error: "not_found" });
  res.json({ messages: staffMessages });
});

function validateChat(body) {
  const b = body && typeof body === "object" ? body : {};
  const msgs = b.messages;
  if (!Array.isArray(msgs) || msgs.length < 1 || msgs.length > 40) return "messages must be a list of 1 to 40 items";
  let total = 0;
  for (const m of msgs) {
    if (!m || (m.role !== "user" && m.role !== "assistant")) return "each message needs a role of user or assistant";
    if (typeof m.content !== "string" || m.content.trim().length < 1 || m.content.length > 1000) return "each message needs 1 to 1000 characters of text";
    total += m.content.length;
  }
  if (total > 12000) return "conversation is too long";
  if (msgs[0].role !== "user") return "the first message must be from the caller";
  if (msgs[msgs.length - 1].role !== "user") return "the last message must be from the caller";
  const s = b.settings && typeof b.settings === "object" ? b.settings : {};
  return {
    history: msgs.map((m) => ({ role: m.role, content: m.content.trim() })),
    settings: { clinicOpen: s.clinicOpen !== false, failBooking: s.failBooking === true },
  };
}

app.post("/api/chat", chatLimiter, async (req, res) => {
  if (!client) {
    return res.status(503).json({ error: "ai_not_configured", message: "Set ANTHROPIC_API_KEY in .env and restart the server." });
  }
  const v = validateChat(req.body);
  if (typeof v === "string") return res.status(400).json({ error: "bad_request", message: v });
  try {
    const out = await runAgent({ client, model: config.model, clinic, calendar, staffMessages, history: v.history, settings: v.settings });
    res.json(out);
  } catch (err) {
    // Log the status only. Error objects can echo request content.
    console.error("agent_error", err?.status ?? err?.name ?? "unknown");
    res.status(502).json({ error: "agent_failed", message: "The AI service didn’t respond. Try again." });
  }
});

app.use("/api", (req, res) => res.status(404).json({ error: "not_found" }));
app.use(express.static(fileURLToPath(new URL("./public", import.meta.url)), { index: "index.html", maxAge: "1h" }));

app.listen(config.port, () => {
  console.log(`${clinic.name} AI receptionist running at http://localhost:${config.port}`);
  if (!client) console.warn("ANTHROPIC_API_KEY is not set. The page loads, but the live agent will report that AI is not configured.");
});
